/* 
  文件名：common.js
  功能：全站通用交互，导航高亮、返回顶部、导航渐变、图片懒加载
  注释：所有交互都在这里，不用新建其他JS
*/
document.addEventListener('DOMContentLoaded', function () {
  // 1. 导航栏当前页面自动高亮
  const links = document.querySelectorAll('.nav-list a');
  const nowPage = location.pathname.split('/').pop();
  links.forEach(link => {
    const href = link.getAttribute('href');
    // 匹配首页和当前页面
    if ((nowPage === '' && href === 'index.html') || href === nowPage) {
      link.style.color = '#ffd700';
      link.style.fontWeight = 'bold';
    }
  });

  // 2. 创建返回顶部按钮
  const backTop = document.createElement('button');
  backTop.innerText = '返回顶部';
  backTop.style.cssText = `
    position: fixed;
    right: 30px;
    bottom: 30px;
    padding: 8px 14px;
    background: #0056b3;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: none;
  `;
  document.body.appendChild(backTop);

  // 3. 滚动监听：控制返回顶部显隐、导航栏透明度
  const navDom = document.querySelector('.nav');
  window.addEventListener('scroll', function () {
    if (window.scrollY > 200) {
      backTop.style.display = 'block';
      navDom.style.background = 'rgba(0, 86, 179, 1)';
    } else {
      backTop.style.display = 'none';
      navDom.style.background = 'rgba(0, 86, 179, 0.9)';
    }
  });

  // 4. 返回顶部点击事件
  backTop.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // 5. 图片懒加载，优化加载速度
  const imgs = document.querySelectorAll('img[data-src]');
  const observer = new IntersectionObserver(items => {
    items.forEach(item => {
      if (item.isIntersecting) {
        item.target.src = item.target.dataset.src;
        observer.unobserve(item.target);
      }
    });
  });
  imgs.forEach(img => observer.observe(img));
});